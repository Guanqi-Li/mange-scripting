import { Navigation, NavigationStack, EnvironmentValuesReader, Script, WebView, VStack, Text, Button, useState, useMemo, useEffect, fetch } from 'scripting'
import { html } from './ui'

type Message = { id?: string, op: string, url?: string, referer?: string, value?: unknown }
type Screen = 'home' | 'reader'

async function handleMessage(p: Message, setScreen: (screen: Screen) => void) {
  try {
    if (p.op === 'screen') {
      if (p.value !== 'home' && p.value !== 'reader') throw new Error('未知界面状态')
      setScreen(p.value)
      return { value: true }
    }
    if (p.op === 'load') return { value: Storage.get('mange.v1') ?? null }
    if (p.op === 'save') {
      if (!Storage.set('mange.v1', p.value)) throw new Error('本地保存失败')
      return { value: true }
    }
    if (p.op === 'fetch' || p.op === 'document' || p.op === 'image') {
      if (!p.url || !/^https:\/\//i.test(p.url)) throw new Error('仅支持 HTTPS 地址')
      const response = await fetch(p.url, {
        timeout: 20,
        headers: { 'User-Agent': 'Mange/1.0 (Android comic reader)', ...(p.referer ? { Referer: p.referer } : {}) }
      })
      if (!response.ok) throw new Error(`HTTP ${response.status}`)
      if (p.op === 'image') {
        const data = await response.data()
        if (data.size > 25 * 1024 * 1024) throw new Error('图片超过 25 MB')
        const mime = (response.headers.get('content-type') || 'image/jpeg').split(';')[0]
        if (!/^image\/(jpeg|png|webp|gif|avif)$/.test(mime)) throw new Error('不支持的图片类型')
        return { value: `data:${mime};base64,${data.toBase64String()}` }
      }
      if (p.op === 'document') {
        const data = await response.data()
        if (data.size > 4 * 1024 * 1024) throw new Error('网页超过 4 MB')
        const text = data.toRawString('utf-8') ?? data.toDecodedString('utf8')
        if (typeof text !== 'string') throw new Error(`网页解码失败，HTTP ${response.status}，字节数 ${data.size}`)
        if (!text.trim()) throw new Error(`网站实际返回空内容，HTTP ${response.status}，字节数 ${data.size}`)
        return { value: { html: text, url: response.url || p.url, status: response.status } }
      }
      return { value: await response.text() }
    }
    throw new Error('未知操作')
  } catch (error) { return { error: error instanceof Error ? error.message : String(error) } }
}

function App({ scheme }: { scheme: string }) {
  const surface = scheme === 'dark' ? '#000000' : '#F2F2F7'
  const controller = useMemo(() => new WebViewController(), [])
  const [screen, setScreen] = useState<Screen>('home')
  const reading = screen === 'reader'
  const [status, setStatus] = useState<string | null>(null)
  const [attempt, setAttempt] = useState(0)
  useEffect(() => {
    let active = true
    let timer: ReturnType<typeof setTimeout> | undefined
    async function initialize() {
      try {
        setStatus(null)
        timer = setTimeout(() => { if (active) setStatus('启动超时。请点重试；若仍失败，请将此提示发给开发者。') }, 15000)
        await controller.addScriptMessageHandler('mange', async incoming => {
          const p = (typeof incoming === 'string' ? JSON.parse(incoming) : incoming) as Message
          if (!p || typeof p.id !== 'string') throw new Error('脚本请求缺少编号')
          const result = await handleMessage(p, setScreen)
          if (active) {
            try {
              await controller.evaluateJavaScript(`window.__mangeReply(${JSON.stringify(p.id)}, ${JSON.stringify(result)}); return true`)
            } catch (error) {
              console.error('MANGE bridge:', String(error))
            }
          }
          return true
        })
        await controller.addScriptMessageHandler('mangeStatus', (p: { error?: string }) => {
          if (active) {
            if (timer) clearTimeout(timer)
            setStatus(p.error ? `启动失败：${p.error}` : '')
          }
          return true
        })
        if (!active) return
        if (!await controller.loadHTML(html.replace('<html lang="zh-CN">', `<html lang="zh-CN" data-native-theme="${scheme}">`))) throw new Error('WebView 未能加载本地界面')
      } catch (error) {
        if (timer) clearTimeout(timer)
        if (active) setStatus(`启动失败：${String(error)}`)
      }
    }
    initialize()
    return () => { active = false; if (timer) clearTimeout(timer) }
  }, [attempt])
  useEffect(() => () => controller.dispose(), [])
  useEffect(() => {
    if (status === '') controller.evaluateJavaScript(`document.documentElement.dataset.nativeTheme = ${JSON.stringify(scheme)}; return true`).catch(() => {})
  }, [scheme, status])
  const toolbar = {
    cancellationAction: <Button title="退出" systemImage="xmark" action={() => Script.exit()} />,
    primaryAction: Script.supportsMinimization() ? <Button title="最小化"
      systemImage="arrow.down.right.and.arrow.up.left"
      action={async () => {
        try {
          if (await Script.minimize()) return
          await Dialog.alert({ message: '当前环境无法最小化，请稍后重试。' })
        } catch (error) {
          await Dialog.alert({ message: `最小化失败：${String(error)}` })
        }
      }} /> : undefined
  }
  return <NavigationStack background={{ style: reading ? '#000000' : surface, shape: 'rect' }} statusBarHidden={reading}
    persistentSystemOverlays={reading ? 'hidden' : 'visible'}
    toolbarBackground={{ style: surface, bars: ['navigationBar'] }}
    toolbarBackgroundVisibility={{ visibility: 'visible', bars: ['navigationBar'] }}>
    <VStack spacing={0} background={{ style: surface, shape: 'rect' }} navigationTitle="MANGE"
      navigationBarTitleDisplayMode="inline" toolbar={toolbar}
      toolbarVisibility={{ visibility: reading ? 'hidden' : 'visible', bars: ['navigationBar'] }}
      toolbarBackground={{ style: surface, bars: ['navigationBar'] }}
      toolbarBackgroundVisibility={{ visibility: 'visible', bars: ['navigationBar'] }}
      ignoresSafeArea={reading}>
      <WebView controller={controller} background={reading ? '#000000' : surface}
        frame={{ maxWidth: 'infinity', maxHeight: 'infinity' }} />
      {status !== '' ? <VStack padding={16}>
        <Text>{status ?? '正在启动 MANGE…'}</Text>
        {status ? <Button title="重试启动" action={() => { setScreen('home'); setAttempt(attempt + 1) }} /> : null}
      </VStack> : null}
    </VStack>
  </NavigationStack>
}

async function main() {
  try {
    await Navigation.present({ element: <EnvironmentValuesReader keys={['colorScheme']}>
      {env => <App scheme={env.colorScheme} />}
    </EnvironmentValuesReader>, modalPresentationStyle: 'fullScreen' })
  } catch (error) {
    console.error('MANGE startup:', String(error))
    await Navigation.present({ element: <VStack padding={20}>
      <Text>MANGE 启动失败：{String(error)}</Text>
      <Button title="退出" action={() => Script.exit()} />
    </VStack> })
  } finally { Script.exit() }
}
main()
